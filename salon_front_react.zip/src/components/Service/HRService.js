import React, { useEffect, useState } from "react";
import axios from "axios";
import HRServiceItems from "./HRServiceItems";

const HRService = (props) => {
  const [service, setService] = useState([]);
  useEffect(() => {
    axios.get("http://127.0.0.1:8000/api/service").then((response) => {
      console.log("Services", response.data.data);
      setService(response.data.data);
    });
  }, []);
  // let ServiceData = props.ServiceData;
  return (
    <section className="prototype_service_info">
      <div className="symbols-pulse active">
        <div className="pulse-1"></div>
        <div className="pulse-2"></div>
        <div className="pulse-3"></div>
        <div className="pulse-4"></div>
        <div className="pulse-x"></div>
      </div>
      <div className="container">
        <h2 className="f_size_30 f_600 t_color3 l_height45 text-center mb_90">
          SaasLand is built for designers like you.
          <br /> With useful features, an intuitive interface.
        </h2>
        <div className="row p_service_info">
          {service.map((item) => {
            return (
              <HRServiceItems
                HRtitle={item.title}
                HRdescription={item.description}
                // Hicon={item.Hicon}
                // rclass={item.rclass}
                // iclass={item.iclass}
                key={item.id}
              />
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default HRService;
