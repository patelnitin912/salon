import React, { useEffect, useState } from "react";
import axios from "axios";
import Blogrightsidebar from "./Blogrightsidebar";
import BlogGridItem from "./BlogGridItem";
import ServiceData from "../Service/ServiceData";
const BlogGrid = () => {
  const [Blog, setBlog] = useState([]);
  useEffect(() => {
    axios.get("http://127.0.0.1:8000/api/blogs").then((response) => {
      console.log(response.data.data);
      setBlog(response.data.data);
    });
  }, []);
  return (
    <section className="blog_area_two sec_pad">
      <div className="container">
        <div className="row">
          <div className="col-lg-8 blog_grid_info">
            <div className="row">
              {Blog.map((blog) => {
                let date = new Date(blog.date).getDate();
                let month = new Date(blog.date).toLocaleString("default", {
                  month: "short",
                });
                return (
                  <BlogGridItem
                    date={date}
                    month={month}
                    image={blog.img}
                    Title={blog.title}
                    description={blog.description}
                    btn="Read More"
                    comment="3"
                  />
                );
              })}
            </div>
            <ul className="list-unstyled page-numbers shop_page_number text-left mt_30">
              <li>
                <span aria-current="page" className="page-numbers current">
                  1
                </span>
              </li>
              <li>
                <a className="page-numbers" href=".#">
                  2
                </a>
              </li>
              <li>
                <a className="next page-numbers" href=".#">
                  <i className="ti-arrow-right"></i>
                </a>
              </li>
            </ul>
          </div>
          <div className="col-lg-4">
            <Blogrightsidebar ServiceData={ServiceData} />
          </div>
        </div>
      </div>
    </section>
  );
};
export default BlogGrid;
